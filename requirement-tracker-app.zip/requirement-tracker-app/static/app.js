(() => {
  "use strict";

  const $ = (id) => document.getElementById(id);

  const requirementInput = $("requirementFile");
  const resourceInput = $("resourceFile");
  const dropReq = $("dropReq");
  const dropRes = $("dropRes");
  const requirementFileName = $("requirementFileName");
  const resourceFileName = $("resourceFileName");
  const analyzeBtn = $("analyzeBtn");
  const uploadMessages = $("uploadMessages");

  const controlsPanel = $("controlsPanel");
  const statGrid = $("statGrid");
  const chartsGrid = $("chartsGrid");
  const statusLine = $("statusLine");
  const clearBtn = $("clearBtn");

  const startDate = $("startDate");
  const endDate = $("endDate");
  const applyRangeBtn = $("applyRangeBtn");
  const allTimeBtn = $("allTimeBtn");
  const downloadCsvBtn = $("downloadCsvBtn");
  const printBtn = $("printBtn");
  const excludedNote = $("excludedNote");

  const STATUS_COLORS = {
    open: "#6C7A93",
    identified: "#E3A94E",
    hold: "#E2694B",
    closed: "#4FBE83",
  };

  // ---------------------------------------------------------------- utils

  function escapeHtml(str) {
    const div = document.createElement("div");
    div.textContent = str;
    return div.innerHTML;
  }

  function showMessage(text, kind) {
    const el = document.createElement("div");
    el.className = `msg ${kind}`;
    el.textContent = text;
    uploadMessages.appendChild(el);
  }

  function clearMessages() {
    uploadMessages.innerHTML = "";
  }

  function setFileLabel(labelEl, dropEl, file) {
    labelEl.textContent = file ? file.name : "Drop file or click to choose";
    dropEl.classList.toggle("has-file", !!file);
  }

  // --------------------------------------------------------- file pickers

  function wireDropzone(dropEl, inputEl, labelEl) {
    dropEl.addEventListener("click", () => inputEl.click());
    inputEl.addEventListener("change", () => {
      setFileLabel(labelEl, dropEl, inputEl.files[0]);
    });
    ["dragover", "dragleave", "drop"].forEach((evt) => {
      dropEl.addEventListener(evt, (e) => e.preventDefault());
    });
    dropEl.addEventListener("dragover", () => dropEl.classList.add("is-dragover"));
    dropEl.addEventListener("dragleave", () => dropEl.classList.remove("is-dragover"));
    dropEl.addEventListener("drop", (e) => {
      dropEl.classList.remove("is-dragover");
      const file = e.dataTransfer.files[0];
      if (file) {
        inputEl.files = e.dataTransfer.files;
        setFileLabel(labelEl, dropEl, file);
      }
    });
  }

  wireDropzone(dropReq, requirementInput, requirementFileName);
  wireDropzone(dropRes, resourceInput, resourceFileName);

  // -------------------------------------------------------------- upload

  analyzeBtn.addEventListener("click", async () => {
    clearMessages();

    const reqFile = requirementInput.files[0];
    const resFile = resourceInput.files[0];

    if (!reqFile && !resFile) {
      showMessage("Choose at least one tracker file first.", "err");
      return;
    }

    const formData = new FormData();
    if (reqFile) formData.append("requirement_file", reqFile);
    if (resFile) formData.append("resource_file", resFile);

    analyzeBtn.disabled = true;
    analyzeBtn.textContent = "Analyzing…";

    try {
      const res = await fetch("/api/upload", { method: "POST", body: formData });
      const data = await res.json();

      if (!res.ok || !data.ok) {
        showMessage(data.error || "Something went wrong while reading the file.", "err");
        return;
      }

      const parts = [];
      if (data.requirement_rows !== undefined) parts.push(`${data.requirement_rows} requirement rows`);
      if (data.resource_rows !== undefined) parts.push(`${data.resource_rows} resource rows`);
      if (parts.length) showMessage(`Loaded ${parts.join(" and ")}.`, "ok");

      (data.warnings || []).forEach((w) => showMessage(w, "warn"));

      controlsPanel.hidden = false;
      statGrid.hidden = false;
      chartsGrid.hidden = false;
      clearBtn.hidden = false;

      await loadDashboard();
    } catch (err) {
      showMessage("Couldn't reach the server. Is app.py still running?", "err");
    } finally {
      analyzeBtn.disabled = false;
      analyzeBtn.textContent = "Analyze data";
    }
  });

  // ------------------------------------------------------------ dashboard

  function currentRange() {
    return { start: startDate.value || "", end: endDate.value || "" };
  }

  async function loadDashboard() {
    const { start, end } = currentRange();
    const params = new URLSearchParams();
    if (start) params.set("start", start);
    if (end) params.set("end", end);

    const res = await fetch(`/api/dashboard?${params.toString()}`);
    const data = await res.json();

    if (!data.data_loaded) return;

    $("statTotal").textContent = data.total;
    $("statOpen").textContent = data.open;
    $("statIdentified").textContent = data.identified;
    $("statHold").textContent = data.hold;
    $("statClosed").textContent = data.closed;
    $("statRgs").textContent = data.rgs_pending;

    renderSkillBars(data.skill_demand);
    renderDonut([
      { label: "Open", value: data.open, color: STATUS_COLORS.open },
      { label: "Identified", value: data.identified, color: STATUS_COLORS.identified },
      { label: "Hold", value: data.hold, color: STATUS_COLORS.hold },
      { label: "Closed", value: data.closed, color: STATUS_COLORS.closed },
    ]);

    const excluded = data.excluded_missing_date || {};
    const totalExcluded = (excluded.requirement || 0) + (excluded.resource || 0);
    if ((start || end) && totalExcluded > 0) {
      excludedNote.hidden = false;
      excludedNote.textContent = `${totalExcluded} row(s) skipped for this period — their date couldn't be read.`;
    } else {
      excludedNote.hidden = true;
    }

    const now = new Date();
    const timeStr = now.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
    const rangeStr = start || end ? `${start || "…"} → ${end || "…"}` : "all time";
    statusLine.textContent = `Showing ${rangeStr} · updated ${timeStr}`;
  }

  applyRangeBtn.addEventListener("click", loadDashboard);
  allTimeBtn.addEventListener("click", () => {
    startDate.value = "";
    endDate.value = "";
    loadDashboard();
  });

  downloadCsvBtn.addEventListener("click", () => {
    const { start, end } = currentRange();
    const params = new URLSearchParams();
    if (start) params.set("start", start);
    if (end) params.set("end", end);
    window.location = `/api/export.csv?${params.toString()}`;
  });

  printBtn.addEventListener("click", () => window.print());

  clearBtn.addEventListener("click", async () => {
    if (!confirm("Clear the uploaded data from memory? You'll need to re-upload to see the dashboard again.")) return;
    await fetch("/api/reset", { method: "POST" });
    location.reload();
  });

  // ------------------------------------------------------------- charts

  function renderSkillBars(skillDemand) {
    const el = $("skillBars");
    if (!skillDemand || !skillDemand.length) {
      el.innerHTML = '<p class="empty">No open requirements in this period.</p>';
      return;
    }
    const max = Math.max(...skillDemand.map((d) => d.count));
    el.innerHTML = skillDemand
      .map(
        (d) => `
      <div class="bar-row">
        <span class="bar-label">${escapeHtml(d.skill)}</span>
        <div class="bar-track"><div class="bar-fill" style="width:${((d.count / max) * 100).toFixed(1)}%"></div></div>
        <span class="bar-value">${d.count}</span>
      </div>`
      )
      .join("");
  }

  // ------------------------------------------------------- restore on load

  async function restoreIfDataExists() {
    try {
      const res = await fetch("/api/dashboard");
      const data = await res.json();
      if (!data.data_loaded) return;

      controlsPanel.hidden = false;
      statGrid.hidden = false;
      chartsGrid.hidden = false;
      clearBtn.hidden = false;
      showMessage("Restored the tracker data already loaded on the server.", "ok");
      await loadDashboard();
    } catch (err) {
      /* server not reachable yet — leave the upload screen showing */
    }
  }

  restoreIfDataExists();

  function renderDonut(segments) {
    const total = segments.reduce((s, x) => s + x.value, 0);
    const chartEl = $("donutChart");
    const legendEl = $("donutLegend");

    legendEl.innerHTML = segments
      .map(
        (s) => `<li><span class="dot" style="background:${s.color}"></span>${s.label}<span class="count">· ${s.value}</span></li>`
      )
      .join("");

    if (total === 0) {
      chartEl.innerHTML = '<p class="empty">No data for this period.</p>';
      return;
    }

    const size = 180;
    const stroke = 26;
    const r = (size - stroke) / 2;
    const c = 2 * Math.PI * r;
    let offset = 0;

    const circles = segments
      .filter((s) => s.value > 0)
      .map((s) => {
        const frac = s.value / total;
        const dash = frac * c;
        const circle = `<circle cx="${size / 2}" cy="${size / 2}" r="${r}" fill="none" stroke="${s.color}" stroke-width="${stroke}" stroke-dasharray="${dash} ${(c - dash).toFixed(2)}" stroke-dashoffset="${(-offset).toFixed(2)}" transform="rotate(-90 ${size / 2} ${size / 2})"/>`;
        offset += dash;
        return circle;
      })
      .join("");

    chartEl.innerHTML = `<svg viewBox="0 0 ${size} ${size}" width="${size}" height="${size}">
      ${circles}
      <text x="50%" y="50%" text-anchor="middle" dominant-baseline="central" class="donut-total">${total}</text>
    </svg>`;
  }
})();
