# Resource & Requirement Tracker — Dashboard

A local dashboard that reads your **Requirement tracker** and **Resource tracker**
(Excel or CSV), and gives you a live-computed summary: Total / Open / Identified /
Hold / Closed / RGS Pending, a skill-demand chart, and a fulfillment-status donut —
filterable by date range, with a one-click CSV report.

Everything runs on your own machine. Nothing is uploaded anywhere else, and no
internet connection is required to use it (a couple of fonts try to load from
Google Fonts for a nicer look, but the app works fine if that's blocked).

This is the "upload & analyze" piece of the bigger project we discussed — the
live email/Teams monitoring, Power Automate flows, and persistent audit trail
are a separate, later phase and are **not** part of this build.

---

## What's in the box

```
requirement-tracker-app/
├── app.py                 Flask backend — file parsing + the analysis logic
├── requirements.txt
├── README.md               (this file)
├── templates/
│   └── index.html
├── static/
│   ├── style.css
│   └── app.js
└── sample_data/
    ├── sample_requirement_tracker.xlsx
    └── sample_resource_tracker.csv     (synthetic data, safe to share)
```

## How to run it

**Requirements:** Python 3.9+ (you mentioned you have 3.12.10, which is perfect).

1. Unzip the project and open a terminal in the `requirement-tracker-app` folder.

2. (Recommended) create a virtual environment:
   ```bash
   python3 -m venv venv
   source venv/bin/activate        # Windows: venv\Scripts\activate
   ```

3. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

4. Run it:
   ```bash
   python app.py
   ```

5. Open **http://localhost:3000** in your browser.

6. Upload your requirement tracker and resource tracker (or try it first with
   the files in `sample_data/`), click **Analyze data**, and the dashboard
   fills in.

To stop the server, press `Ctrl+C` in the terminal.

---

## How the analysis works

The app doesn't assume your columns are in a fixed order — it looks for
columns **by name** (case-insensitive), so it tolerates the kind of column
drift that happens when a tracker gets edited over time.

**From the Requirement tracker:**
| What it looks for | Column name it searches for |
|---|---|
| Status | a column named "Status" (falls back to any column containing "status", excluding "Detailed Status") |
| Skill | a column named "Skill" (falls back to "Skill Category") |
| Date (for the time-period filter) | "Requirement Open date" / "Open date", falling back to any "date" column that isn't a billing date |
| Requirement ID | "Requirement ID" |

Status text is normalized into four buckets:
- contains **"close"** → **Closed**
- contains **"hold"** → **Hold**
- contains **"identif"** → **Identified**
- anything else (including blank) → **Open**

**From the Resource tracker:**
| What it looks for | Column name it searches for |
|---|---|
| RGS Pending | a column with "RGS" in the name (falls back to "RMG"); counts rows whose value contains "pending" |
| Date | any column named "Date" |

**Skill demand chart:** counts *Open* requirements per skill. If a cell lists
multiple skills ("Java, Springboot, React"), only the first one is used as the
primary skill for grouping — real free-text skill fields are messy, and this
keeps the chart readable rather than fragmenting into dozens of one-off
combinations. If you'd rather count every listed skill separately, that's a
quick change in `primary_skill()` in `app.py`.

**Time-period filter:** when you set a From/To date, rows whose date can't be
read are excluded from that view (and the dashboard tells you how many were
skipped) — the assumption is if we can't confirm a row belongs in the window,
it shouldn't be silently counted in or out.

### If your counts look off

Open your browser's dev tools → Network tab → look at the response from
`/api/upload` after you analyze a file. It reports exactly which column it
matched for each field (or `null` if it didn't find one). If a match is
wrong, the fix is almost always to rename the column in your source file to
match what's listed above, or to add your column's exact name to the
`find_column(...)` keyword list for that field in `app.py`.

---

## Known limitations (by design, for this phase)

- **Data lives in memory only**, for as long as `app.py` keeps running.
  Restarting it clears everything — there's no database yet. That's
  intentional for this phase; Postgres comes in later per the roadmap.
- **Single user at a time.** This isn't built for multiple people uploading
  different files concurrently — it's a local tool for one person's session.
- **No PDF export** — use the **Print / Save as PDF** button, which uses your
  browser's built-in print-to-PDF with a print-friendly layout.
- Sidebar items marked **Soon** (Review queue, Activity & changes, Resources,
  Weekly insights) are placeholders for the later phases we discussed —
  they're not wired up yet.

## Tested with

The backend logic (upload, column detection, status counting, RGS-pending
counting, date filtering, CSV export) was run end-to-end against the sample
data in `sample_data/` before this was packaged, including one `.xlsx` and
one `.csv` file to confirm both formats parse correctly.
