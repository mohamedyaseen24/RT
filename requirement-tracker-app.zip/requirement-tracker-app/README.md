# Resource & Requirement Tracker — Dashboard

A local dashboard that reads your **Requirement tracker** and **Resource tracker**
(Excel or CSV), and gives you a live-computed summary: Total / Open / Identified /
Hold / Closed / RGS Pending, a skill-demand chart, and a fulfillment-status donut —
filterable by date range, with a one-click CSV report.

Everything runs on your own machine. Nothing is uploaded anywhere else, and no
internet connection is required to use it (a couple of fonts try to load from
Google Fonts for a nicer look, but the app works fine if that's blocked).

This is the "upload & analyze" piece of the bigger project we discussed — the
live email/Teams monitoring, Power Automate flows, and persistent audit trail
are a separate, later phase and are **not** part of this build.

---

## What's in the box

```
requirement-tracker-app/
├── app.py                 Flask backend — file parsing + the analysis logic
├── requirements.txt
├── README.md               (this file)
├── templates/
│   └── index.html
├── static/
│   ├── style.css
│   └── app.js
└── sample_data/
    ├── sample_requirement_tracker.xlsx
    └── sample_resource_tracker.csv     (synthetic data, safe to share)
```

## How to run it

**Requirements:** Python 3.9+ (you mentioned you have 3.12.10, which is perfect).

1. Unzip the project and open a terminal in the `requirement-tracker-app` folder.

2. (Recommended) create a virtual environment:
   ```bash
   python3 -m venv venv
   source venv/bin/activate        # Windows: venv\Scripts\activate
   ```

3. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

4. Run it:
   ```bash
   python app.py
   ```

5. Open **http://localhost:3000** in your browser.

6. Upload your requirement tracker and resource tracker (or try it first with
   the files in `sample_data/`), click **Analyze data**, and the dashboard
   fills in.

To stop the server, press `Ctrl+C` in the terminal.

---

## How the analysis works

Real trackers are almost never one flat table — they're workbooks with a
dozen-plus tabs (per-account raw data, pivots, summaries, archived quarters).
Pandas' default of "just read the first sheet" is wrong more often than it's
right for files like that, so this app doesn't do that. Instead, for each
uploaded workbook it:

1. **Reads every sheet**, not just the first.
2. **Scores each sheet's header row** against a signature for what a real
   tracker tab looks like, and combines every sheet that matches — so a
   workbook with your data spread across "P&C," "Banking," "SWBC,"
   "Life IT," etc. gets read as one unified table, while summary/pivot tabs
   ("Detailed Summary," "Skill Wise Summary," a "Fulfillment" rollup, and
   so on) are correctly left out.
3. **Detects each sheet's key columns by name**, independently per sheet —
   important because column names can drift between tabs in the same
   workbook (one real example found in testing: most tabs call it "Status,"
   one tab calls the same column "Open"). Detecting per-sheet and renaming
   to a common internal name before combining means that kind of drift
   doesn't silently corrupt the combined totals.
4. For the **RGS Pending** count specifically, the app doesn't trust the
   column *name* at all — it scans every column's actual *values* for
   RMG/RGS-style status text ("RMG Pending," "R/RMG Approved," etc.) and
   uses whichever column's content actually looks like that. This matters
   because real files aren't consistent: one sheet's column literally named
   "RGS" turned out to hold a numeric ID, while the real status text was in
   a column named "RMG Approved" — and *another* sheet in the same workbook
   had that same status text sitting in a column just called "Status."
   Matching by name would have picked the wrong column, or missed it
   entirely, in either case.

**Sheet detection specifics**, if you want to tune it (both are in `app.py`):

| Tracker | Requires this column... | ...plus 2 of these |
|---|---|---|
| Requirement | "Account/Portfolio" | Status, Skill, Requirement ID |
| Resource | Emp ID / Emp No / Emp # | RGS, RMG, Skill |

If no sheet matches, it falls back to the first sheet rather than loading
nothing, and tells you so in a warning.

**Status normalization**, once the right column is found:
- contains **"close"** → **Closed**
- contains **"hold"** → **Hold**
- contains **"identif"** → **Identified**
- anything else (including blank) → **Open**

**Skill demand chart:** counts *Open* requirements per skill. If a cell lists
multiple skills ("Java, Springboot, React"), only the first one is used as the
primary skill for grouping — real free-text skill fields are messy, and this
keeps the chart readable rather than fragmenting into dozens of one-off
combinations. If you'd rather count every listed skill separately, that's a
quick change in `primary_skill()` in `app.py`.

**Time-period filter:** when you set a From/To date, rows whose date can't be
read are excluded from that view (and the dashboard tells you how many were
skipped) — the assumption is if we can't confirm a row belongs in the window,
it shouldn't be silently counted in or out.

### If your counts look off

After you click Analyze, the app tells you exactly which sheets it combined
and which it skipped, right in the upload panel — start there. If a sheet
that should count got skipped, or one that shouldn't got included, that's
the place to look. Beyond that, your browser's dev tools → Network tab →
the response from `/api/upload` has the same information in full, including
per-sheet row counts.

---

## Known limitations (by design, for this phase)

- **Data lives in memory only**, for as long as `app.py` keeps running.
  Restarting it clears everything — there's no database yet. That's
  intentional for this phase; Postgres comes in later per the roadmap.
- **Single user at a time.** This isn't built for multiple people uploading
  different files concurrently — it's a local tool for one person's session.
- **No PDF export** — use the **Print / Save as PDF** button, which uses your
  browser's built-in print-to-PDF with a print-friendly layout.
- Sidebar items marked **Soon** (Review queue, Activity & changes, Resources,
  Weekly insights) are placeholders for the later phases we discussed —
  they're not wired up yet.

## Tested with

The backend logic (multi-sheet detection and combining, per-sheet column
drift, value-based RGS detection, status counting, date filtering, CSV
export) was validated end-to-end against a real multi-tab requirement
tracker (30 sheets) and resource tracker (13 sheets) before this was
packaged — confirming, sheet by sheet, that the right tabs were combined and
the wrong ones correctly skipped, and cross-checking the final counts by
hand against the raw data. Those real files aren't included here for privacy
reasons; `sample_data/` has small synthetic stand-ins instead, one `.xlsx`
and one `.csv`, to confirm both formats parse correctly.
