"""
Resource & Requirement Tracker — backend

A small local Flask app that:
  1. accepts an uploaded Requirement tracker + Resource tracker (xlsx/xls/csv),
  2. figures out which SHEETS actually hold tracker line-items (real workbooks
     like yours have a dozen+ tabs — summaries, pivots, per-account raw data —
     and pandas' default of "just read the first sheet" is wrong more often
     than it's right), and which columns on those sheets hold status / skill /
     dates / RGS info (by name, not by fixed position),
  3. serves a JSON summary (+ a CSV export) that the dashboard renders.

Data lives in memory only, for the lifetime of the running process — nothing
is written to disk. Restarting the app clears it. Use POST /api/reset to
clear it on demand without restarting.
"""

import csv
import io
from datetime import date

import pandas as pd
from flask import Flask, Response, jsonify, render_template, request

app = Flask(__name__)

# ---------------------------------------------------------------------------
# In-memory state
# ---------------------------------------------------------------------------

STATE = {
    "requirement_df": None,
    "resource_df": None,
}

# ---------------------------------------------------------------------------
# Sheet-detection rules
#
# A workbook tab counts as "requirement tracker data" if its header row has
# BOTH an anchor column (something that only a real portfolio line-item sheet
# would have) AND at least MIN_SIGNATURE of the signature keywords. This is
# what lets the app tell "P&C" (real data) apart from "Detailed Summary" or
# "Q4 Demand tracker" (real sheets in the same workbook, wrong shape) without
# you having to point at a specific tab by name.
# ---------------------------------------------------------------------------

REQUIREMENT_ANCHOR = ["account/portfolio", "account & portfolio"]
REQUIREMENT_SIGNATURE = ["status", "skill", "requirement id"]
REQUIREMENT_MIN_SIGNATURE = 2

RESOURCE_ANCHOR = ["emp id", "emp no", "emp #", "employee id"]
RESOURCE_SIGNATURE = ["rgs", "rmg", "skill"]
RESOURCE_MIN_SIGNATURE = 2


# ---------------------------------------------------------------------------
# Helpers: reading files & finding columns
# ---------------------------------------------------------------------------

def load_all_tables(file_storage):
    """Read every sheet of an uploaded file into {sheet_name: DataFrame}.

    A .csv has no sheets, so it comes back as a single entry. Empty sheets
    and fully-empty rows/columns are dropped up front so they don't skew
    detection or row counts later.
    """
    filename = (file_storage.filename or "").lower()

    if filename.endswith(".csv"):
        df = pd.read_csv(file_storage)
        df.columns = [str(c).strip() for c in df.columns]
        return {"(uploaded csv)": df}

    try:
        xls = pd.ExcelFile(file_storage, engine="openpyxl")
    except Exception:
        file_storage.stream.seek(0)
        xls = pd.ExcelFile(file_storage)

    tables = {}
    for name in xls.sheet_names:
        try:
            df = xls.parse(name)
        except Exception:
            continue
        df.columns = [str(c).strip() for c in df.columns]
        df = df.dropna(how="all")  # drop fully-empty rows only; a column that's
        # blank for THIS account (e.g. Requirement ID never filled in) still
        # needs to stay, or sheet detection loses its name and fails to match.
        if len(df):
            tables[name] = df
    return tables


def find_column(columns, keywords, exclude=None):
    """Find a column whose name matches one of `keywords`, by name not position.

    Tries an exact (case-insensitive) match first, then a substring match.
    `exclude` skips columns whose name contains any of those substrings.
    """
    exclude = exclude or []
    lowered = {c: str(c).strip().lower() for c in columns}

    for original, low in lowered.items():
        if low in keywords:
            return original

    for original, low in lowered.items():
        if any(ex in low for ex in exclude):
            continue
        if any(kw in low for kw in keywords):
            return original

    return None


def header_text(columns):
    return " | ".join(str(c).strip().lower() for c in columns)


def sheet_matches(columns, anchors, sig_kws, min_sig, require_anchor=True):
    text = header_text(columns)
    has_anchor = any(a in text for a in anchors) if require_anchor else True
    sig_count = sum(1 for kw in sig_kws if kw in text)
    return has_anchor and sig_count >= min_sig


def rename_requirement_columns(df):
    """Map this sheet's own column names onto fixed internal names.

    Doing this PER SHEET (rather than after combining everything) is what
    lets two sheets in the same workbook use different names for the same
    thing — one real example from testing: most tabs call it "Status", one
    calls the same column "Open". Without a per-sheet rename, that tab's
    status values would silently vanish into a separate, mismatched column
    after combining.
    """
    cols = list(df.columns)
    status_col = find_column(cols, ["status"], exclude=["detailed"])
    skill_col = find_column(cols, ["skill"])
    date_col = find_column(cols, ["open date", "requirement open date"]) or find_column(
        cols, ["date"], exclude=["billing"]
    )
    id_col = find_column(cols, ["requirement id", "req id"])

    mapping = {}
    if status_col:
        mapping[status_col] = "__status__"
    if skill_col:
        mapping[skill_col] = "__skill__"
    if date_col:
        mapping[date_col] = "__date__"
    if id_col:
        mapping[id_col] = "__id__"
    return df.rename(columns=mapping)


def find_rgs_status_column(df):
    """Find whichever column holds RMG/RGS approval text, by VALUE not by name.

    Real-world tracker seen in testing: one sheet's status text lived in a
    column named "RMG Approved"; another sheet's equivalent text lived in a
    column just named "Status", while ITS "RGS"-named column was a numeric
    ID. Matching by column name is unreliable here — the values themselves
    (containing "RMG"/"RGS", e.g. "RMG Pending", "R/RMG Reject") are the
    only reliable signal.
    """
    best, best_score = None, 0.0
    for c in df.columns:
        vals = df[c].dropna().astype(str).str.lower()
        if len(vals) < 10:  # skip near-empty stray columns so they can't win by a fluke
            continue
        score = vals.str.contains("rmg|rgs", regex=True).mean()
        if score > best_score:
            best, best_score = c, score
    return best if best_score > 0.3 else None


def rename_resource_columns(df):
    rgs_col = find_rgs_status_column(df)
    date_col = find_column(list(df.columns), ["date"])

    mapping = {}
    if rgs_col:
        mapping[rgs_col] = "__rgs__"
    if date_col:
        mapping[date_col] = "__date__"
    return df.rename(columns=mapping)


def select_and_merge(tables, anchors, sig_kws, min_sig, rename_fn):
    """Pick every sheet that looks like tracker data and stack them into one table.

    Falls back in two stages if nothing matches cleanly: first by dropping
    the anchor requirement, then — as a last resort, so the app never just
    silently loads nothing — by using the first sheet in the file.
    """
    included, skipped, frames = [], [], []

    for name, df in tables.items():
        if sheet_matches(df.columns, anchors, sig_kws, min_sig, require_anchor=True):
            frames.append(rename_fn(df))
            included.append({"sheet": name, "rows": len(df)})
        else:
            skipped.append(name)

    if not frames:
        for name, df in tables.items():
            if sheet_matches(df.columns, anchors, sig_kws, min_sig, require_anchor=False):
                frames.append(rename_fn(df))
                included.append({"sheet": name, "rows": len(df)})
                if name in skipped:
                    skipped.remove(name)

    fallback_used = False
    if not frames:
        fallback_used = True
        first_name = next(iter(tables))
        frames = [rename_fn(tables[first_name])]
        included = [{"sheet": first_name, "rows": len(tables[first_name])}]
        skipped = [n for n in tables if n != first_name]

    combined = pd.concat(frames, ignore_index=True, sort=False)
    return combined, {
        "included_sheets": included,
        "skipped_sheets": skipped,
        "total_rows": len(combined),
        "fallback_used": fallback_used,
    }


def normalize_status(raw):
    """Map any raw status text to one of OPEN / IDENTIFIED / HOLD / CLOSED.

    Blank or unrecognised values default to OPEN, since an un-set status
    on a live requirement almost always means work hasn't started yet.
    """
    if raw is None:
        return "OPEN"
    s = str(raw).strip().lower()
    if not s or s == "nan":
        return "OPEN"
    if "close" in s:
        return "CLOSED"
    if "hold" in s:
        return "HOLD"
    if "identif" in s:
        return "IDENTIFIED"
    return "OPEN"


def primary_skill(raw):
    """Reduce a possibly multi-skill cell ('Java, Springboot, React') to one label."""
    s = str(raw).strip()
    for sep in (",", "/", "&", ";", "|"):
        if sep in s:
            s = s.split(sep)[0]
            break
    return s.strip() or "Unspecified"


def apply_date_filter(df, date_col, start, end):
    """Filter df to rows whose date_col falls within [start, end].

    Returns (filtered_df, excluded_count). If no date column is known, or no
    range was requested, returns the df untouched. When a range IS requested,
    rows with a missing/unparseable date are excluded (we can't confirm
    they belong in the window) and counted so the UI can say so.
    """
    if df is None or date_col is None or date_col not in df.columns or (not start and not end):
        return df, 0

    dates = pd.to_datetime(df[date_col], errors="coerce")
    mask = dates.notna()
    if start:
        mask &= dates >= pd.to_datetime(start)
    if end:
        mask &= dates <= pd.to_datetime(end)

    excluded = int((~mask).sum())
    return df[mask], excluded


# ---------------------------------------------------------------------------
# Core computation, shared by the dashboard endpoint and the CSV export
# ---------------------------------------------------------------------------

def compute_summary(start, end):
    req_df = STATE["requirement_df"]
    res_df = STATE["resource_df"]

    if req_df is None and res_df is None:
        return {"data_loaded": False}

    filtered_req, excluded_req = apply_date_filter(req_df, "__date__", start, end)
    filtered_res, excluded_res = apply_date_filter(res_df, "__date__", start, end)

    total = open_c = identified = hold = closed = 0
    skill_demand = []

    if filtered_req is not None and len(filtered_req):
        if "__status__" in filtered_req.columns:
            statuses = filtered_req["__status__"].apply(normalize_status)
        else:
            statuses = pd.Series(["OPEN"] * len(filtered_req), index=filtered_req.index)

        total = len(filtered_req)
        open_c = int((statuses == "OPEN").sum())
        identified = int((statuses == "IDENTIFIED").sum())
        hold = int((statuses == "HOLD").sum())
        closed = int((statuses == "CLOSED").sum())

        if "__skill__" in filtered_req.columns:
            open_mask = statuses == "OPEN"
            skills = filtered_req.loc[open_mask, "__skill__"].dropna().apply(primary_skill)
            counts = skills.value_counts().head(8)
            skill_demand = [{"skill": k, "count": int(v)} for k, v in counts.items()]

    rgs_pending = 0
    if filtered_res is not None and len(filtered_res) and "__rgs__" in filtered_res.columns:
        vals = filtered_res["__rgs__"].astype(str).str.lower()
        rgs_pending = int(vals.str.contains("pending").sum())

    return {
        "data_loaded": True,
        "requirement_loaded": req_df is not None,
        "resource_loaded": res_df is not None,
        "total": total,
        "open": open_c,
        "identified": identified,
        "hold": hold,
        "closed": closed,
        "rgs_pending": rgs_pending,
        "skill_demand": skill_demand,
        "excluded_missing_date": {"requirement": excluded_req, "resource": excluded_res},
    }


# ---------------------------------------------------------------------------
# Routes
# ---------------------------------------------------------------------------

@app.route("/")
def index():
    return render_template("index.html")


@app.route("/api/upload", methods=["POST"])
def upload():
    req_file = request.files.get("requirement_file")
    res_file = request.files.get("resource_file")

    if not req_file and not res_file:
        return jsonify({"ok": False, "error": "No files were received."}), 400

    warnings = []
    notes = []
    result = {"ok": True}

    if req_file and req_file.filename:
        try:
            tables = load_all_tables(req_file)
            if not tables:
                raise ValueError("the file has no readable sheets/rows")
            combined, report = select_and_merge(
                tables, REQUIREMENT_ANCHOR, REQUIREMENT_SIGNATURE, REQUIREMENT_MIN_SIGNATURE, rename_requirement_columns
            )
        except Exception as exc:
            return jsonify({"ok": False, "error": f"Couldn't read the requirement tracker file: {exc}"}), 400

        STATE["requirement_df"] = combined
        result["requirement_rows"] = report["total_rows"]
        result["requirement_sheets_included"] = report["included_sheets"]
        result["requirement_sheets_skipped"] = report["skipped_sheets"]

        sheet_names = "; ".join(s["sheet"] for s in report["included_sheets"])
        if report["fallback_used"]:
            warnings.append(
                f"Couldn't confidently identify a requirement-tracker sheet — used '{sheet_names}' as a best guess. "
                "If that's the wrong tab, tell me its actual name and I'll adjust the detection."
            )
        elif len(report["included_sheets"]) > 1:
            notes.append(f"Combined {len(report['included_sheets'])} sheets from the requirement tracker: {sheet_names}.")
        else:
            notes.append(f"Read the requirement tracker from the '{sheet_names}' sheet.")

        if "__status__" not in combined.columns:
            warnings.append("Couldn't find a Status column in the requirement tracker — every row is being counted as Open.")
        if "__skill__" not in combined.columns:
            warnings.append("Couldn't find a Skill column in the requirement tracker — the skill chart will be empty.")
        if "__date__" not in combined.columns:
            warnings.append("Couldn't find a date column in the requirement tracker — time-period filtering won't apply to it.")

    if res_file and res_file.filename:
        try:
            tables2 = load_all_tables(res_file)
            if not tables2:
                raise ValueError("the file has no readable sheets/rows")
            combined2, report2 = select_and_merge(
                tables2, RESOURCE_ANCHOR, RESOURCE_SIGNATURE, RESOURCE_MIN_SIGNATURE, rename_resource_columns
            )
        except Exception as exc:
            return jsonify({"ok": False, "error": f"Couldn't read the resource tracker file: {exc}"}), 400

        STATE["resource_df"] = combined2
        result["resource_rows"] = report2["total_rows"]
        result["resource_sheets_included"] = report2["included_sheets"]
        result["resource_sheets_skipped"] = report2["skipped_sheets"]

        sheet_names2 = "; ".join(s["sheet"] for s in report2["included_sheets"])
        if report2["fallback_used"]:
            warnings.append(
                f"Couldn't confidently identify a resource-tracker sheet — used '{sheet_names2}' as a best guess. "
                "If that's the wrong tab, tell me its actual name and I'll adjust the detection."
            )
        elif len(report2["included_sheets"]) > 1:
            notes.append(f"Combined {len(report2['included_sheets'])} sheets from the resource tracker: {sheet_names2}.")
        else:
            notes.append(f"Read the resource tracker from the '{sheet_names2}' sheet.")

        if "__rgs__" not in combined2.columns:
            warnings.append("Couldn't find an RGS/RMG column in the resource tracker — RGS Pending will show 0.")

    result["notes"] = notes
    result["warnings"] = warnings
    return jsonify(result)


@app.route("/api/dashboard")
def dashboard():
    start = request.args.get("start") or None
    end = request.args.get("end") or None
    return jsonify(compute_summary(start, end))


@app.route("/api/export.csv")
def export_csv():
    start = request.args.get("start") or None
    end = request.args.get("end") or None
    summary = compute_summary(start, end)

    if not summary.get("data_loaded"):
        return jsonify({"ok": False, "error": "No data has been uploaded yet."}), 400

    buf = io.StringIO()
    writer = csv.writer(buf)
    writer.writerow(["Resource & Requirement Tracker — report"])
    writer.writerow(["Period", f"{start or 'All time'} to {end or 'All time'}"])
    writer.writerow(["Generated", date.today().isoformat()])
    writer.writerow([])
    writer.writerow(["Metric", "Count"])
    writer.writerow(["Total", summary["total"]])
    writer.writerow(["Open", summary["open"]])
    writer.writerow(["Identified", summary["identified"]])
    writer.writerow(["Hold", summary["hold"]])
    writer.writerow(["Closed", summary["closed"]])
    writer.writerow(["RGS Pending", summary["rgs_pending"]])
    writer.writerow([])
    writer.writerow(["Skill", "Open requirements"])
    for row in summary["skill_demand"]:
        writer.writerow([row["skill"], row["count"]])

    return Response(
        buf.getvalue(),
        mimetype="text/csv",
        headers={"Content-Disposition": f"attachment; filename=requirement_report_{date.today().isoformat()}.csv"},
    )


@app.route("/api/reset", methods=["POST"])
def reset():
    STATE["requirement_df"] = None
    STATE["resource_df"] = None
    return jsonify({"ok": True})


if __name__ == "__main__":
    # debug=True gives auto-reload while you're developing, but also exposes
    # the interactive debugger — fine on localhost, so feel free to flip it
    # on while you're changing things.
    app.run(debug=False, port=3000)
