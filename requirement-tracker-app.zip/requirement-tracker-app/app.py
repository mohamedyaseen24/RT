"""
Resource & Requirement Tracker — backend

A small local Flask app that:
  1. accepts an uploaded Requirement tracker + Resource tracker (xlsx/xls/csv),
  2. figures out which columns hold status / skill / dates / RGS info
     (by name, not by fixed position, so it tolerates real-world column drift),
  3. serves a JSON summary (+ a CSV export) that the dashboard renders.

Data lives in memory only, for the lifetime of the running process — nothing
is written to disk. Restarting the app clears it. Use POST /api/reset to
clear it on demand without restarting.
"""

import csv
import io
from datetime import date

import pandas as pd
from flask import Flask, Response, jsonify, render_template, request

app = Flask(__name__)

# ---------------------------------------------------------------------------
# In-memory state
# ---------------------------------------------------------------------------

STATE = {
    "requirement_df": None,
    "resource_df": None,
    "requirement_cols": {},
    "resource_cols": {},
}


# ---------------------------------------------------------------------------
# Helpers: reading files & finding columns
# ---------------------------------------------------------------------------

def read_table(file_storage):
    """Read an uploaded xlsx/xls/csv file into a DataFrame."""
    filename = (file_storage.filename or "").lower()

    if filename.endswith((".xlsx", ".xlsm")):
        df = pd.read_excel(file_storage, engine="openpyxl")
    elif filename.endswith(".xls"):
        df = pd.read_excel(file_storage)
    elif filename.endswith(".csv"):
        df = pd.read_csv(file_storage)
    else:
        # Unknown extension: try Excel first, fall back to CSV.
        try:
            df = pd.read_excel(file_storage, engine="openpyxl")
        except Exception:
            file_storage.stream.seek(0)
            df = pd.read_csv(file_storage)

    df.columns = [str(c).strip() for c in df.columns]
    # Drop fully-empty rows/columns that often trail behind exported sheets.
    df = df.dropna(how="all").dropna(axis=1, how="all")
    return df


def find_column(columns, keywords, exclude=None):
    """Find a column whose name matches one of `keywords`, by name not position.

    Tries an exact (case-insensitive) match first, then a substring match.
    `exclude` skips columns whose name contains any of those substrings.
    """
    exclude = exclude or []
    lowered = {c: str(c).strip().lower() for c in columns}

    for original, low in lowered.items():
        if low in keywords:
            return original

    for original, low in lowered.items():
        if any(ex in low for ex in exclude):
            continue
        if any(kw in low for kw in keywords):
            return original

    return None


def normalize_status(raw):
    """Map any raw status text to one of OPEN / IDENTIFIED / HOLD / CLOSED.

    Blank or unrecognised values default to OPEN, since an un-set status
    on a live requirement almost always means work hasn't started yet.
    """
    if raw is None:
        return "OPEN"
    s = str(raw).strip().lower()
    if not s or s == "nan":
        return "OPEN"
    if "close" in s:
        return "CLOSED"
    if "hold" in s:
        return "HOLD"
    if "identif" in s:
        return "IDENTIFIED"
    return "OPEN"


def primary_skill(raw):
    """Reduce a possibly multi-skill cell ('Java, Springboot, React') to one label."""
    s = str(raw).strip()
    for sep in (",", "/", "&", ";", "|"):
        if sep in s:
            s = s.split(sep)[0]
            break
    return s.strip() or "Unspecified"


def apply_date_filter(df, date_col, start, end):
    """Filter df to rows whose date_col falls within [start, end].

    Returns (filtered_df, excluded_count). If no date column is known, or no
    range was requested, returns the df untouched. When a range IS requested,
    rows with a missing/unparseable date are excluded (we can't confirm
    they belong in the window) and counted so the UI can say so.
    """
    if df is None or date_col is None or (not start and not end):
        return df, 0

    dates = pd.to_datetime(df[date_col], errors="coerce")
    mask = dates.notna()
    if start:
        mask &= dates >= pd.to_datetime(start)
    if end:
        mask &= dates <= pd.to_datetime(end)

    excluded = int((~mask).sum())
    return df[mask], excluded


# ---------------------------------------------------------------------------
# Core computation, shared by the dashboard endpoint and the CSV export
# ---------------------------------------------------------------------------

def compute_summary(start, end):
    req_df = STATE["requirement_df"]
    res_df = STATE["resource_df"]

    if req_df is None and res_df is None:
        return {"data_loaded": False}

    req_cols = STATE["requirement_cols"]
    res_cols = STATE["resource_cols"]

    filtered_req, excluded_req = apply_date_filter(req_df, req_cols.get("date"), start, end)
    filtered_res, excluded_res = apply_date_filter(res_df, res_cols.get("date"), start, end)

    total = open_c = identified = hold = closed = 0
    skill_demand = []

    if filtered_req is not None and len(filtered_req):
        status_col = req_cols.get("status")
        if status_col:
            statuses = filtered_req[status_col].apply(normalize_status)
        else:
            statuses = pd.Series(["OPEN"] * len(filtered_req), index=filtered_req.index)

        total = len(filtered_req)
        open_c = int((statuses == "OPEN").sum())
        identified = int((statuses == "IDENTIFIED").sum())
        hold = int((statuses == "HOLD").sum())
        closed = int((statuses == "CLOSED").sum())

        skill_col = req_cols.get("skill")
        if skill_col:
            open_mask = statuses == "OPEN"
            skills = filtered_req.loc[open_mask, skill_col].dropna().apply(primary_skill)
            counts = skills.value_counts().head(8)
            skill_demand = [{"skill": k, "count": int(v)} for k, v in counts.items()]

    rgs_pending = 0
    if filtered_res is not None and len(filtered_res):
        rgs_col = res_cols.get("rgs")
        if rgs_col:
            vals = filtered_res[rgs_col].astype(str).str.lower()
            rgs_pending = int(vals.str.contains("pending").sum())

    return {
        "data_loaded": True,
        "requirement_loaded": req_df is not None,
        "resource_loaded": res_df is not None,
        "total": total,
        "open": open_c,
        "identified": identified,
        "hold": hold,
        "closed": closed,
        "rgs_pending": rgs_pending,
        "skill_demand": skill_demand,
        "excluded_missing_date": {"requirement": excluded_req, "resource": excluded_res},
    }


# ---------------------------------------------------------------------------
# Routes
# ---------------------------------------------------------------------------

@app.route("/")
def index():
    return render_template("index.html")


@app.route("/api/upload", methods=["POST"])
def upload():
    req_file = request.files.get("requirement_file")
    res_file = request.files.get("resource_file")

    if not req_file and not res_file:
        return jsonify({"ok": False, "error": "No files were received."}), 400

    warnings = []
    result = {"ok": True}

    if req_file and req_file.filename:
        try:
            df = read_table(req_file)
        except Exception as exc:
            return jsonify({"ok": False, "error": f"Couldn't read the requirement tracker file: {exc}"}), 400

        cols = list(df.columns)
        status_col = find_column(cols, ["status"], exclude=["detailed"])
        skill_col = find_column(cols, ["skill"])
        date_col = find_column(cols, ["open date", "requirement open date"]) or find_column(
            cols, ["date"], exclude=["billing"]
        )
        id_col = find_column(cols, ["requirement id", "req id"])

        STATE["requirement_df"] = df
        STATE["requirement_cols"] = {
            "status": status_col,
            "skill": skill_col,
            "date": date_col,
            "id": id_col,
        }
        result["requirement_rows"] = len(df)
        result["requirement_columns"] = STATE["requirement_cols"]

        if not status_col:
            warnings.append("Couldn't find a Status column in the requirement tracker — every row is being counted as Open.")
        if not skill_col:
            warnings.append("Couldn't find a Skill column in the requirement tracker — the skill chart will be empty.")
        if not date_col:
            warnings.append("Couldn't find a date column in the requirement tracker — time-period filtering won't apply to it.")

    if res_file and res_file.filename:
        try:
            df2 = read_table(res_file)
        except Exception as exc:
            return jsonify({"ok": False, "error": f"Couldn't read the resource tracker file: {exc}"}), 400

        cols2 = list(df2.columns)
        rgs_col = find_column(cols2, ["rgs"]) or find_column(cols2, ["rmg"])
        date_col2 = find_column(cols2, ["date"])

        STATE["resource_df"] = df2
        STATE["resource_cols"] = {"rgs": rgs_col, "date": date_col2}
        result["resource_rows"] = len(df2)
        result["resource_columns"] = STATE["resource_cols"]

        if not rgs_col:
            warnings.append("Couldn't find an RGS/RMG column in the resource tracker — RGS Pending will show 0.")

    result["warnings"] = warnings
    return jsonify(result)


@app.route("/api/dashboard")
def dashboard():
    start = request.args.get("start") or None
    end = request.args.get("end") or None
    return jsonify(compute_summary(start, end))


@app.route("/api/export.csv")
def export_csv():
    start = request.args.get("start") or None
    end = request.args.get("end") or None
    summary = compute_summary(start, end)

    if not summary.get("data_loaded"):
        return jsonify({"ok": False, "error": "No data has been uploaded yet."}), 400

    buf = io.StringIO()
    writer = csv.writer(buf)
    writer.writerow(["Resource & Requirement Tracker — report"])
    writer.writerow(["Period", f"{start or 'All time'} to {end or 'All time'}"])
    writer.writerow(["Generated", date.today().isoformat()])
    writer.writerow([])
    writer.writerow(["Metric", "Count"])
    writer.writerow(["Total", summary["total"]])
    writer.writerow(["Open", summary["open"]])
    writer.writerow(["Identified", summary["identified"]])
    writer.writerow(["Hold", summary["hold"]])
    writer.writerow(["Closed", summary["closed"]])
    writer.writerow(["RGS Pending", summary["rgs_pending"]])
    writer.writerow([])
    writer.writerow(["Skill", "Open requirements"])
    for row in summary["skill_demand"]:
        writer.writerow([row["skill"], row["count"]])

    return Response(
        buf.getvalue(),
        mimetype="text/csv",
        headers={"Content-Disposition": f"attachment; filename=requirement_report_{date.today().isoformat()}.csv"},
    )


@app.route("/api/reset", methods=["POST"])
def reset():
    STATE["requirement_df"] = None
    STATE["resource_df"] = None
    STATE["requirement_cols"] = {}
    STATE["resource_cols"] = {}
    return jsonify({"ok": True})


if __name__ == "__main__":
    # debug=True gives auto-reload while you're developing, but also exposes
    # the interactive debugger — fine on localhost, so feel free to flip it
    # on while you're changing things.
    app.run(debug=False, port=3000)
